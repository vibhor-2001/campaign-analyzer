# Campaign Analyzer — Streamlit Cloud Deployment

## HOW TO DEPLOY (one time, takes 5 minutes)

### Step 1 — Create a free GitHub account
Go to github.com and sign up if you do not have one.

### Step 2 — Create a new repository
- Click the + button top right
- Click "New repository"
- Name it: campaign-analyzer
- Set it to Public
- Click "Create repository"

### Step 3 — Upload the files
- Click "uploading an existing file" link on the repo page
- Drag both files into the upload area:
    - app.py
    - requirements.txt
- Click "Commit changes"

### Step 4 — Deploy on Streamlit Cloud
- Go to share.streamlit.io
- Sign in with your GitHub account
- Click "New app"
- Select your repository: campaign-analyzer
- Main file path: app.py
- Click "Deploy"

### Step 5 — Share the link
After 2-3 minutes it will give you a link like:
https://yourname-campaign-analyzer-app-xxxx.streamlit.app

Share that link with your CEO. They just open it in any browser.
No installation. No code. Nothing to set up.

---

## HOW YOUR CEO USES IT

1. Open the link in any browser
2. Click "Upload Promomash file(s)" in the sidebar
3. Upload one or more Excel files
4. Use the sidebar filters:
   - Campaign (if multiple campaigns in the file)
   - Date Range (pick any date window)
   - State (filter to specific states)
   - BA Ambassador (filter to specific BAs)
5. All charts and tables update instantly
6. Go to the Download tab to get the Excel report

---

## FILES NEEDED
- app.py          — the main app
- requirements.txt — the packages Streamlit Cloud will install
